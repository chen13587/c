
#ifndef SHA1_BASE64_H_
#define SHA1_BASE64_H_

void sha1_base64(char *recvbuf,char *buf);



#endif /* SHA1_BASE64_H_ */
